# 1.初识ElasticSearch

## 1.1.了解ES

### 1.1.1.什么是ElasticSearch

elasticsearch是一款非常强大的开源搜索引擎,可以帮助我们从海量数据中快速找到需要的内容。

比如：

* 在github搜索项目

![](images/image.png)

* 在电商平台搜索商品

![](images/image-1.png)

* Google搜答案

![](images/image-2.png)

* 打车软件搜索附近的车

![](images/image-3.png)

### 1.1.2.ELK技术栈

elasticsearch结合kibana、Logstash、Beats,也就是elassticstack(ELK)。被广泛应用在日志数据分析、实时监控

等领域。

![](images/image-4.png)

elasticsearch是elastic stack的核心,负责存储、搜索、分析数据。

![](images/image-5.png)

### 1.1.3.elasticsearch和lucene

elasticsearch底层是基于lucene来实现的

Lucene是一个Java语言的搜索引擎类库,是Apache公司的顶级项目,由DougCutting于1999年研发。

官网地址:https://lucene.apache.org/。

![](images/image-6.png)

**elasticsearch**的发展历史：

* 2004年Shay Banon基于Lucene开发了Compass

* 2010年Shay Banon 重写了Compass，取名为Elasticsearch。

![](images/image-7.png)

### 1.1.4.为什么不是其他搜索技术？

目前比较知名的搜索引擎技术排名：

![](images/image-8.png)

虽然在早期，Apache Solr是最主要的搜索引擎技术，但随着发展elasticsearch已经渐渐超越了Solr，独占鳌头：



![](images/image-9.png)

### 1.1.5.总结

**什么是elasticsearch?**

* 一个开源的分布式搜索引擎,可以用来实现搜索、日志统计、分析、系统监控等功能

**什么是elasticstack(ELK)?**

* 是以elasticsearch为核心的技术栈,包括beats、Logstash、kibana、elasticsearch

**什么是Lucene?**

* 是Apache的开源搜索引擎类库,提供了搜索引擎的核心API

***

## 1.2.倒排索引和正向索引

### 1.2.1.正向索引

传统数据库（如MySQL）采用正向索引，例如给下表（tb\_gOods）中的id创建索引：

![](images/image-10.png)

如果是根据id查询，那么直接走索引，查询速度非常快。

但如果是基于title做模糊查询，**只能是逐行扫描数据，**&#x6D41;程如下：

1. 用户搜索数据，条件是title符合"%手机%"

2. 逐行获取数据，比如id为1的数据

3. 判断数据中的title是否符合用户搜索条件

4. 如果符合则放入结果集，不符合则丢弃，回到步骤1

逐行扫描，也就是全表扫描，随着数据量增加，其查询效率也会越来越低。



### 1.2.2.正向索引的优缺点

* 优点

1. **更新简单**

一个文档的内容发生变化，只需要更新该文档那一条记录，不影响其他文档。

* **结构简单**

文档自身直接存储分词结果，不需要复杂的 posting list 或 term dictionary。

* **适合按文档进行处理的任务**

如：

* 文本分类

* 推荐系统（协同过滤）

* TF-IDF 统计按文档聚合

* Embedding / 向量检索

❌ 缺点

1. **关键词搜索非常慢**

要搜索某个词，必须检查所有文档 → O(N) 扫描。

例：搜索 `"search"`
&#x20;→ 需要遍历所有文档检查是否含该词。

* **无法支持短语查询**

例如 `"search engine"`
&#x20;正向索引必须查所有文档并比较位置，非常慢。

* **无法做前缀搜索、高亮等功能**

因为不按 Term 组织数据。



### 1.2.3.倒排索引

倒排索引是搜索引擎（如 Elasticsearch、Lucene）最核心的数据结构，用于实现**全文检索**。

其本质是：

> **由 “词 → 文档” 的映射结构（term → document list）**

即：倒排索引不关心“文档里有哪些词”（正排），而关注“一个词在哪些文档里出现”。

倒排索引由两个核心构成：



在倒排索引中有两个非常重要的概念：

* 文档（Document）：我们要用来搜索的数据，其中搜索到的每一条数据就是一个文档，例如一个用户信息，一个百度词条。

  **每条 Document 会被 ES 存储，并经过分析器（Analyzer）转换为一个个词条（Term）。**

  🌟 文档的特点：

  * 是最小的可检索单位

  * 每条文档有一个 `_id`（ES 内部会使用 docID）

  * 文档的原文（source）可选是否存储，但索引结构一定会生成

* 词条（`Term`）：词条是ES 分词后得到的 **标准化后的最小检索单元，**&#x5BF9;文档数据或用户搜索数据，利用某种算法分词，得到的具备含义的词语就是词条。

  * 例如：我是中国人，就可以分为：我、是、中国人、中国、国人这样的几个词条

  * 例如句子："Elasticsearch is a search engine"，经过 standard analyzer：\["elasticsearch", "is", "a", "search", "engine"]，这些小写后的字符串就是 **term**。

  🌟 Term 的特征：

  * 统一大小写（小写化）

  * 去除停用词（stop words，如 “the”）

  * 通过分词器分析得到

  * 存在 **倒排词典（Term Dictionary）** 中

如图：

![](images/image-11.png)

**文档 → Term：倒排索引的创建过程**

假设有以下两个文档：

**文档 1：**

`"I love Elasticsearch"`

**文档 2：**

`"Elasticsearch is fast"`

分词后：

构建倒排索引：

* **Term Dictionary（倒排词典）**

词典存储所有词条：

`["elasticsearch","fast","i","is","love"]`

词典会用\*\*前缀压缩（FST）\*\*结构存储，以减少内存占用，并实现高效的前缀查找。

***

* **Posting List（倒排列表）**

每个 term 会对应一个*出现该词的文档列表*。

以 term = "elasticsearch" 为例：

```plain&#x20;text
Term: "elasticsearch"
Posting List:
    docID: [1, 2]
    freq:  [1, 1]  // term frequency，每个文档出现几次
    positions: [
        [2],       // 文档 1 中 term 出现的位置
        [1]        // 文档 2 中 term 出现的位置
    ]
```

Posting List 中常包含：



![](images/image-12.png)

虽然要先查询倒排索引，再查询文档id，但是无论是词条、还是文档id都建立了索引，查询速度非常快！无需全表扫描。



### 1.2.4.对比

那么为什么一个叫正向索引，一个叫倒排索引呢？

* **正向索引**是最传统的，根据id索引的方式。但根据词条查询时，必须先逐条获取每个文档，然后判断文档中是否包含所需要的词条，**是根据文档找词条的过程。**

* **倒排索引**则是先找到用户要搜索的词条，根据词条得到保护词条的文档的id，然后根据id获取文档。是**根据词条找文档的过程**

### 1.2.5.倒排索引的优缺点

✅ 优点

1. **关键词搜索速度极快（O(logN）或更好）**

搜索 `"search"`
&#x20;→ 直接查

`search → [doc1, doc2, doc5...]`

无需扫描所有文档。

* **天然支持短语查询、位置查询**

因为 posting list 中可以存储词位置信息（positions）。

* **能做前缀、模糊、近似、范围搜索**

Term Dictionary（如 Lucene 的 FST）提供了高效前缀匹配能力：

`sea* → search, seat, season...`

* **适合全文检索、排序（BM25）、高亮等功能**

倒排结构能快速统计 TF、DF，计算 BM25。

❌ 缺点

1. **更新成本高**

文档修改会影响多个 Term 的 posting list：

&#x20;例如一个 1000 字的文档变更 → 要更新数十至数百个 Term。

这是为什么 Elasticsearch 最终采用：

Segment 追加写（不可变）

定期 merge

而不是直接修改倒排索引。

* **构建复杂，存储结构重**

需要维护：

Term dictionary（FST）

Posting lists（docID、freq、position、offset）

压缩机制（delta-encoding、bit packing）

* **占用空间较大（虽然高度压缩）**

倒排索引为了速度牺牲了一些空间。

* **不适合按文档处理的任务**

例如想查“文档有哪些词”，倒排索引不擅长（需正向索引或 stored fields）。



### 1.2.6.什么时候用正向索引？什么时候用倒排索引？

**✔ 使用正向索引的典型场景**

推荐系统 / Embedding 检索

文档相似度计算（按文档组织数据更方便）

在向量数据库中（如 Milvus/FAISS）



**✔ 使用倒排索引的典型场景**

**搜索引擎（Elasticsearch, Solr, Lucene）**

日志检索（ELK）

搜索关键词、短语、高亮

支持丰富的文本查询语法

两者经常组合使用：

> Elasticsearch 内部也有正排索引（Stored Fields、DocValues）用于排序和聚合，但全文检索仍依赖倒排索引。

***





## 1.3.es的一些概念

elasticsearch中有很多独有的概念，与mysql中略有差别，但也有相似之处。



### 1.3.1.文档和字段

elasticsearch是面向**文档（Document）存储的，可以是数据库中的一条商品数据，一个订单信息。文档数据会被序列化为json格式后存储在elasticsearch中：**

![](images/image-13.png)

**而Json文档中往往包含很多的字段（Field）**，类似于数据库中的列。



### 1.3.2.索引和映射

**索引（Index）**，就是相同类型的文档的集合。

例如：

* 所有用户文档，就可以组织在一起，称为用户的索引；

* 所有商品的文档，可以组织在一起，称为商品的索引；

* 所有订单的文档，可以组织在一起，称为订单的索引；

![](images/image-14.png)

因此，我们可以把索引当做是数据库中的表。

数据库的表会有约束信息，用来定义表的结构、字段的名称、类型等信息。因此，索引库中就有**映射（mapping）**，是索引中文档的字段约束信息，类似表的结构约束。



### 1.3.3.mysql和elasticsearch概念对比

![](images/image-15.png)

是不是说，我们学习了elasticsearch就不再需要mysql了呢？

并不是如此，两者各自有自己的擅长之处：



Mysql：擅长事务类型操作，可以确保数据的安全和一致性

Elasticsearch：擅长海量数据的搜索、分析、计算

**因此在企业中，往往是两者结合使用：**

* 对安全性要求较高的写操作，使用mysql实现

* 对查询性能要求较高的搜索需求，使用elasticsearch实现

* 两者再基于某种方式，实现数据的同步，保证一致性

![](images/image-16.png)



## 1.4.下载ES和ES分词器还有Kibana

https://blog.csdn.net/qq\_27130997/article/details/119390780

官网：https://www.elastic.co/cn/downloads/past-releases

首先要创建网络：因为我们还需要部署kibana容器，因此需要让es和kibana容器互联。这里先创建一个网络

```plain&#x20;text
docker network create es7-net
```

### 1.4.1.安装ES

在官网下载ES7.12.0后，将elasticsearch-7.12.1.tar.gz文件拖到root目录下，解压即可

```plain&#x20;text
tar -zxvf /root/elasticsearch-7.12.1.tar.gz -C /opt/es/
```

**参数解释：**

* `z`：解压 `.gz`

* `x`：extract（解包）

* `v`：verbose（显示详细过程，可不加）

* `f`：指定文件名

* `-C`：指定解压目标目录（目录必须存在）

解压完以后运行如下命令创建es7容器

```plain&#x20;text
docker run -d --name es7 \
  -p 9200:9200 -p 9300:9300 \
  -e "discovery.type=single-node" \
  -e "xpack.security.enabled=false" \
  -v es-data:/opt/elasticsearch-7.12.1/data \
  -v es-plugins:/opt/elasticsearch-7.12.1/plugins \
  --network es7-net \
  -e "ES_JAVA_OPTS=-Xms1g -Xmx1g" \
  docker.elastic.co/elasticsearch/elasticsearch:7.12.1
```

**命令解释：**

* `-e "discovery.type=single-node"`：设置为单节点模式

* `-e "xpack.security.enabled=false"`：关闭安全认证（无需账号密码）

* `-e "ES_JAVA_OPTS=-Xms1g -Xmx1g"`：设置 ES JVM 内存为 1GB

* `-p 9200:9200`：映射 HTTP 访问端口

* `-p 9300:9300`：映射集群通信端口

* `-v es-data:/opt/elasticsearch-7.12.1/data`：挂载数据目录，持久化 ES 数据

* `-v es-plugins:/opt/elasticsearch-7.12.1/plugins`：挂载插件目录

* `--network es7-net`：加入名为 es7-net 的 Docker 网络

* `--name es7`：容器名称

* `-d`：后台运行

* `docker.elastic.co/elasticsearch/elasticsearch:7.12.1`：指定 ES 版本镜像

在游览器输入Linux本机的ip地址加端口

```plain&#x20;text
http://192.168.150.101:9200 //这里的ip地址一定要是你本机的地址
```

即可看到elasticsearch的响应结果：

![](images/image-17.png)

### 1.4.2.安装Kibana

在官网下载Kibana后，将kibana7.12.1.tar.gz文件拖到root目录下，解压即可

```plain&#x20;text
tar -zxvf /root/kibana7.12.1.tar.gz -C /opt/kibana/
```

解压完以后运行如下命令创建kibana容器

```bash
docker run -d --name kibana \
  -p 5601:5601 \
  -e ELASTICSEARCH_HOSTS=http://es7:9200 \
  --network es7-net \
  kibana:7.12.1
```

命令解释：

* `-d`：后台运行

* `--name kibana`：容器名称为 kibana

* `-p 5601:5601`：映射 Kibana Web UI 端口

* `-e ELASTICSEARCH_HOSTS=http://es7:9200`：指定 Kibana 连接的 Elasticsearch 地址（通过容器名 es7 访问）

* `--network es7-net`：加入与 Elasticsearch 相同的 Docker 网络，才能互相访问

* `kibana:7.12.1`：使用 Kibana 7.12.1 镜像

此时，在浏览器输入地址访问：

```plain&#x20;text
http://192.168.150.101:5601 //这里的ip地址一定要是你本机的地址
```

即可看到：

![](images/image-18.png)



kibana中提供了一个DevTools界面：

![](images/image-19.png)

![](images/image-20.png)

![](images/image-21.png)

这个界面中可以编写DSL来操作elasticsearch。并且对DSL语句有自动补全功能。
我们做个简单demo,点击发送后，收到

![](images/image-22.png)

### 1.4.3.安装IK分词器

把 IK 插件 zip 放到 **宿主机** 的 `/opt/elasticsearch-7.12.1`，接下来只需要 **复制进容器并离线安装** 即可。

***

✅ 第一步：把 ZIP 文件复制进 ES 容器

我的容器名是`es7`

执行：

`docker cp /opt/elasticsearch-7.12.1/elasticsearch-analysis-ik-7.12.1.zip es7:/usr/share/elasticsearch/`

复制完成后，进入容器：

`docker exec -it es7 bash`

***

✅ 第二步：在容器内部执行离线安装

在容器里运行：

`cd /usr/share/elasticsearch
elasticsearch-plugin install file:///usr/share/elasticsearch/elasticsearch-analysis-ik-7.12.1.zip`

⚠ 注意：
`file:///` 前面必须是三个 `/`，否则会报路径解析错误。

***

✅ 第三步：退出容器并重启 ES

退出：

`exit`

重启容器：

`docker restart es7`

***

✅ 第四步：确认 IK 插件是否安装成功

执行：

`curl localhost:9200/_cat/plugins?v`

成功的话应该看到类似：

`es7 analysis-ik 7.12.1`

## 1.5.IK分词器的拓展和停用词典

**扩展词典：**

在实际的文本处理过程中，语言的表达方式随着互联网的发展而不断演变。尤其是在社交媒体、短视频平台和年轻用户群体的推动下，各类网络新词层出不穷，传统词典往往无法及时收录这些词汇。例如：

* “魂穿”

* “上大分”

* “奥力给”

* “知识付费”

* “打瓦”

这类词语在原有的 IK 分词器词库中并不存在，因此如果不进行扩展，分词过程中将会被错误拆分，影响搜索质量与数据分析效果。

为了适应快速变化的语言环境，IK 分词器提供了 **扩展词典（ext.dic）** 机制，允许我们手动为系统添加新词。在业务系统中，只要遇到新的实体词、行业术语、品牌名、自造词等，都可以通过扩展词典加入到 IK 的分词库，使得分词结果更加准确。

在演示扩展功能之前，我们可以先尝试一下 IK 默认行为，观察它是如何拆分一个未收录的新词，从而理解扩展词典的必要性。

```plain&#x20;text
POST /_analyze
{
  "text": "传智播客很牛逼克拉斯外加恐龙抗狼加我嘞个豆",
  "analyzer": "ik_smart"
}
```

可以看到分词都是一个字一个字的，说明目前的词典里面没有这些词

![](images/image-23.png)

1. 打开IK分词器config目录：

> 声明：由于某种原因，我的IK分词器没有config目录，所以我把config目录建在了/opt/ik-config下，并创建了以下三个文件

```plain&#x20;text
[root@localhost ik-config]# docker exec -it 56582d69e884 bash
[root@56582d69e884 elasticsearch]# ls /usr/share/elasticsearch/plugins/analysis-ik/config
```

![](images/image-24.png)

* 通过命令打开文件：

```plain&#x20;text
vim IKAnalyzer.cfg.xml
```

![](images/image-25.png)

新增ext.dic用于添加新词语

新增stopword.dic用于禁用词语

```plain&#x20;text
[root@localhost ~]# cd /opt/ik-config/
[root@localhost ik-config]# touch ext.dic
[root@localhost ik-config]# touch stopword.dic
```

* 可以在ext.dic中添加如下内容：

![](images/image-26.png)

* 然后重启es

```plain&#x20;text
docker restart es

# 查看 日志
docker logs -f elasticsearch
```

* 测试结果：

```plain&#x20;text
POST /_analyze
{
  "text": "传智播客很牛逼克拉斯外加恐龙抗狼加我嘞个豆",
  "analyzer": "ik_max_word"
}
```

> 注意当前文件的编码必须是 UTF-8 格式，严禁使用Windows记事本编辑







**停用词典：**

在互联网项目中，在网络间传输的速度很快，所以很多语言是不允许在网络上传递的，如：关于宗教、政治等敏感词语，那么我们在搜索时也应该忽略当前词汇。

IK分词器也提供了强大的停用词功能，让我们在索引时就直接忽略当前的停用词汇表中的内容。

* 编辑stopword.dic，添加停用词

![](images/image-27.png)

* 重启es

```plain&#x20;text
# 重启服务
docker restart es
docker restart kibana

# 查看 日志
docker logs -f es
```

* 测试结果：

```plain&#x20;text
# 测试新颖的词语
POST /_analyze
{
  "text": "看了视频记得一键三连，拒绝白嫖，预防电信诈骗，点赞投币加收藏，谢谢你的喜欢，奥里给",
  "analyzer": "ik_max_word"
}

```

![](images/image-28.png)

> 注意当前文件的编码必须是 UTF-8 格式，严禁使用Windows记事本编辑



## 1.6.总结

1.4.3.总结

分词器的作用是什么？

* 创建倒排索引时对文档分词

* 用户搜索时，对输入的内容分词

IK分词器有几种模式？

* ik\_smart：智能切分，粗粒度

* ik\_max\_word：最细切分，细粒度

IK分词器如何拓展词条？如何停用词条？

* 利用config目录的IkAnalyzer.cfg.xml文件添加拓展词典和停用词典

* 在词典中添加拓展词条或者停用词条





# 2.索引库操作

## 2.1.mapping映射属性

索引库就类似数据库表，mapping映射就类似表的结构。

**Mapping（映射）= 定义 Elasticsearch 中每个字段的类型和行为。**

类似于数据库中的 **表结构 + 字段类型 + 索引规则**。

Mapping 决定：

* 字段怎么存储？

* 用什么方式索引？

* 是否可搜索？

* 是否分词？

* 是否排序/聚合？

* 是否启用全文检索？

常见的mapping属性包括：

* type：字段数据类型，常见的简单类型有：

  * 字符串：text（可分词的文本，可以拆分）、keyword（精确值，例如：品牌、国家、ip地址，不能拆分）

  * 数值：long、integer、short、byte、double、float、

  * 布尔：boolean

  * 日期：date

  * 对象：object

* index：是否创建索引，默认为true，不参与搜索就设置false

* analyzer：使用哪种分词器

  * ik\_smart：智能切分，粗粒度

  * ik\_max\_word：最细切分，细粒度

* properties：该字段的子字段，代表某个字段的子属性



## 2.2.索引库操作

### 2.2.1.创建索引

例如下面的Json文档：

```bash
{
    "age": 21,
    "weight": 52.1,
    "isMarried": false,
    "info": "黑马程序员Java讲师",
    "email": "zy@itcast.cn",
    "score": [99.1, 99.5, 98.9],
    "name": {
        "firstName": "云",
        "lastName": "赵"
    }
}
```

对应的每个字段映射（mapping）：

* age：类型为 integer；参与搜索，因此需要index为true；无需分词器

* weight：类型为float；参与搜索，因此需要index为true；无需分词器、

* isMarried：类型为boolean；参与搜索，因此需要index为true；无需分词器

* info：类型为字符串，需要分词，因此是text；参与搜索，因此需要index为true；分词器可以用ik\_smart

* email：类型为字符串，但是不需要分词，因此是keyword；不参与搜索，因此需要index为false；无需分词器

* score：虽然是数组，但是我们只看元素的类型，类型为float；参与搜索，因此需要index为true；无需分词器

* name：类型为object，需要定义多个子属性

  * name.firstName；类型为字符串，但是不需要分词，因此是keyword；参与搜索，因此需要index为true；无需分词器

  * name.lastName；类型为字符串，但是不需要分词，因此是keyword；参与搜索，因此需要index为true；无需分词器

```bash
# 创建索引库
PUT /heima
{
  "mappings": {
    "properties": {
      "info": {
        "type": "text",
        "analyzer": "standard"
      },
      "email": {
        "type": "keyword",
        "index": false
      },
      "name": {
        "type": "object",
        "properties": {
          "firstName": {
            "type": "keyword"
          },
          "lastName": {
            "type": "keyword"
          }
        }
      }
    }
  }
}
```

***

### 2.2.2.查看索引

**查看所有索引**

```plain&#x20;text
GET _cat/indices?v
```

**查看指定索引**

```plain&#x20;text
GET /索引库名
```

**查看 mapping**

```plain&#x20;text
GET /索引库名/_mapping
```

**查看 setting**

```plain&#x20;text
GET /索引库名/_settings
```

***

### 2.2.3.删除索引

```plain&#x20;text
DELETE /索引名
```

***

### 2.2.4.修改索引

注意：ES 7.x 不允许修改字段类型！！！

**不过可以添加新的字段,但是这个新字段不能和原有的字段重复**

```plain&#x20;text
# 修改索引库，添加新字段
PUT /heima/_mapping
{
  "properties": {
    "age": {
      "type": "long"
    }
  }
}
```

如果非要修改原有字段，可以使用**重建索引**的方式：

1. 创建新索引

```plain&#x20;text
PUT /index_new
{
  "settings": {...},
  "mappings": {...}
}
```

* 用 reindex 把数据从旧索引复制到新索引

```json
POST _reindex
{
  "source": {
    "index": "my_index"
  },
  "dest": {
    "index": "my_index_new"
  }
}
```

* 删除老索引、别名切换

```sql
DELETE my_index
PUT _aliases
{
  "actions": [
    {"add": {"index": "my_index_new", "alias": "my_index"}}
  ]
}
```

***



# 3.文档操作

## 3.1.新增文档

* 语法：

```bash
POST /索引库名/_doc/文档id
{
    "字段1": "值1",
    "字段2": "值2",
    "字段3": {
        "子属性1": "值3",
        "子属性2": "值4"
    },
    // ...
}
```

* 示例：

```bash
POST /heima/_doc/1
{
    "info": "黑马程序员Java讲师",
    "email": "zy@itcast.cn",
    "name": {
        "firstName": "云",
        "lastName": "赵"
    }
}
```

***

## 3.2.查询文档

* 语法：

```plain&#x20;text
GET /索引库名/_doc/文档id
```

* 实例：

```plain&#x20;text
GET /heima/_doc/1
```

***

## 3.3.删除文档

* 语法

```plain&#x20;text
DELETE /索引库名/_doc/文档id
```

* 示例：

```plain&#x20;text
DELETE /heima/_doc/1
```

***

## 3.4.修改文档

修改有两种方式：

* 全量修改：直接覆盖原来的文档

* 增量修改：修改文档中的部分字段



### 3.4.1.全量修改

全量修改是**覆盖**原来的文档，其本质是：

* 根据指定的id删除文档

* 新增一个相同id的文档

**注意**：如果根据id删除时，id不存在，第二步的新增也会执行，也就从修改变成了新增操作了。

**语法：**

```plain&#x20;text
PUT /{索引库名}/_doc/文档id
{
    "字段1": "值1",
    "字段2": "值2",
    // ... 略
}
```

**示例：**

```bash
# 修改文档
PUT /heima/_doc/1
{
  "info": "黑马程序员讲师",
  "email": "zy@itcast.cn",
  "name": {
        "firstName": "云",
        "lastName": "赵"
    }
}
```



### 3.4.2.增量修改

增量修改是只修改指定id匹配的文档中的部分字段。

**语法：**

```plain&#x20;text
POST /索引库名/_update/文档id
{
    "doc": {
         "字段名": "新的值",
    }
}
```

**示例：**

```plain&#x20;text
# 修改文档 局部修改，只修改指定的字段
POST /heima/_update/1
{
  "doc": {
    "email" : "keyi@itcast.cn"
  }
}
```

***

3.5.总结

文档操作有哪些？

* 创建文档：POST /{索引库名}/\_doc/文档id { json文档 }

* 查询文档：GET /{索引库名}/\_doc/文档id

* 删除文档：DELETE /{索引库名}/\_doc/文档id

* 修改文档：

  * 全量修改：PUT /{索引库名}/\_doc/文档id { json文档 }

  * 增量修改：POST /{索引库名}/\_update/文档id { “doc”: {字段}}

***



# 4.RestAPI

ES官方提供了各种不同语言的客户端，用来操作ES。这些客户端的本质就是组装DSL语句，通过http请求发送给ES。

官方文档地址：[RestAPI官网](https://www.elastic.co/guide/en/elasticsearch/client/index.html)

其中的Java Rest Client又包括两种：

* Java Low Level Rest Client

* Java High Level Rest Client

![](images/image-29.png)

我们学习的是Java HighLevel Rest Client客户端API



## 4.1.导入Demo工程

案例

**利用JavaRestClient实现创建、删除索引库，判断索引库是否存在，根据课前资料提供的酒店数据创建索引库,索引库名为hotel, mapping属性根据数据库结构定义。**

基本步骤如下:

* 导入课前资料Demo

* 分析数据结构,定义mapping属性

* 初始化JavaRestClient

* 利用JavaRestClient创建索引库

* 利用JavaRestClient删 除索引库

* 利用JavaRestClient判 断索引库是否存在

## 4.2.导入数据库数据

在课前资料中有一个sql文件：

![](images/image-30.png)

表结构如下：

```sql
CREATE TABLE `tb_hotel` (
  `id` bigint(20) NOT NULL COMMENT '酒店id',
  `name` varchar(255) NOT NULL COMMENT '酒店名称；例：7天酒店',
  `address` varchar(255) NOT NULL COMMENT '酒店地址；例：航头路',
  `price` int(10) NOT NULL COMMENT '酒店价格；例：329',
  `score` int(2) NOT NULL COMMENT '酒店评分；例：45，就是4.5分',
  `brand` varchar(32) NOT NULL COMMENT '酒店品牌；例：如家',
  `city` varchar(32) NOT NULL COMMENT '所在城市；例：上海',
  `star_name` varchar(16) DEFAULT NULL COMMENT '酒店星级，从低到高分别是：1星到5星，1钻到5钻',
  `business` varchar(255) DEFAULT NULL COMMENT '商圈；例：虹桥',
  `latitude` varchar(32) NOT NULL COMMENT '纬度；例：31.2497',
  `longitude` varchar(32) NOT NULL COMMENT '经度；例：120.3925',
  `pic` varchar(255) DEFAULT NULL COMMENT '酒店图片；例:/img/1.jpg',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

```

## 4.3.导入hotel-demo项目

然后导入课前资料提供的项目：

![](images/image-31.png)

项目结构如图：

![](images/image-32.png)



## 4.4.mapping映射分析

创建索引库，最关键的是mapping映射，而mapping映射要考虑的信息包括：

* 字段名

* 字段数据类型

* 是否参与搜索

* 是否需要分词

* 如果分词，分词器是什么？

其中：

* 字段名、字段数据类型，可以参考数据表结构的名称和类型

* 是否参与搜索要分析业务来判断，例如图片地址，就无需参与搜索

* 是否分词呢要看内容，内容如果是一个整体就无需分词，反之则要分词

* 分词器，我们可以统一使用ik\_max\_word

其中：

* **字段名、字段数据类型，可以参考数据表结构的名称和类型**

* **是否参与搜索要分析业务来判断，例如图片地址，就无需参与搜索**

* **是否分词呢要看内容，内容如果是一个整体就无需分词，反之则要分词**

* **分词器，我们可以统一使用`ik_max_word`**

![](images/image-33.png)

来看下酒店数据的索引库结构:

**注意：这个结构是我自己写的，和课程不同，如果想要课程结构，往下看。**

```json
PUT hotel
{
  "mappings": {
    "properties": {
      "id": {
        "type": "long"
      },
      "name": {
        "type": "text",
        "analyzer": "ik_max_word", 
        "search_analyzer": "ik_smart"
      },
      "address": {
        "type": "text",
        "analyzer": "ik_max_word"
      },
      "price": {
        "type": "integer"
      },
      "score": {
        "type": "scaled_float",
        "scaling_factor": 10
      },
      "brand": {
        "type": "keyword"
      },
      "city": {
        "type": "keyword"
      },
      "star_name": {
        "type": "keyword"
      },
      "business": {
        "type": "text",
        "analyzer": "ik_max_word",
        "fields": {
          "keyword": { "type": "keyword" }
        }
      },
      "location": {
        "type": "geo_point"
      },
      "pic": {
        "type": "keyword",
        "index": false
      }
    }
  }
}

```

**为什么这样设计？**

* `id → long`

主键，不需要全文检索。

***

* `name → text（全文搜索）`

酒店名称用户会输入关键字搜索。

使用 `text + IK 分词器`：

ik\_max\_word：最大化分词，适合文档入库

ik\_smart：更智能，用于查询减少噪音

***

* `address → text`

地址也可能参与搜索，如“浦东”“虹桥”。

***

* `price → integer`

用于排序、区间筛选（如价格从 200–500）。

***

* `score → scaled_float`

你的评分是 45 代表 4.5，因此：

需要保留小数

`scaled_float` 比 `double` 存储更高效

```plain&#x20;text
"type": "scaled_float",
"scaling_factor": 10
```

45 → ES 内部存为 4.5

***

* `brand / city / star_name → keyword`

这些是分类筛选字段，不进行全文搜索。

特点：

可用于 terms 聚合

可用于过滤（filter）

可用于精确匹配

***

* `business → text + keyword`

商圈用于：

搜索（text）

聚合筛选（keyword）

所以采用多字段：

```plain&#x20;text
"fields": {
  "keyword": { "type": "keyword" }
}
```

***

* `latitude + longitude → geo_point`

ES 地理搜索必须使用：

```plain&#x20;text
"type": "geo_point"
```

并将数据改为：

```plain&#x20;text
"location": "31.2497,120.3925"
```

这样可以：

搜附近酒店

按距离排序

显示范围圈选

***

* `pic → keyword，index: false`

图片地址只做展示，不用搜索：

```plain&#x20;text
"index": false
```

减少存储 & 提升写入性能。

***

**这个是课程索引结构：**

```bash
# 创建酒店索引
PUT /hotel
{
  "mappings": {
    "properties": {
      "id": {
        "type": "keyword"
      },
      "name": {
        "type": "text",
        "analyzer": "ik_max_word",
        "copy_to": "all"
      },
      "address": {
        "type": "keyword",
        "index": false
      },
      "price": {
        "type": "integer"
      },
      "score": {
        "type": "integer"
      },
      "brand": {
        "type": "keyword",
        "copy_to": "all"
      },
      "city": {
        "type": "keyword"
      },
      "starName": {
        "type": "keyword"
      },
      "business": {
        "type": "keyword",
        "copy_to": "all"
      },
      "location": {
        "type": "geo_point"
      },
      "pic": {
        "type": "keyword",
        "index": false
      },
      "all": {
        "type": "text",
        "index": true,
        "analyzer": "ik_max_word"
      }
    }
  }
}

```

几个特殊字段说明：

* location：地理坐标，里面包含精度、纬度

* all：一个组合字段，其目的是将多字段的值 利用copy\_to合并，提供给用户搜索



地理坐标说明：这里的酒店坐标我们用geo\_point

![](images/image-34.png)

copy\_to说明：同时根据多个字段搜索

![](images/image-35.png)





## 4.5.初始化RestClient

在elasticsearch提供的API中，与elasticsearch一切交互都封装在一个名为RestHighLevelClient的类中，必须先完成这个对象的初始化，建立与elasticsearch的连接。
分为三步：

1. 引入es的RestHighLevelClient依赖：

```plain&#x20;text
<dependency>
    <groupId>org.elasticsearch.client</groupId>
    <artifactId>elasticsearch-rest-high-level-client</artifactId>
</dependency>
```

* 因为SpringBoot默认的ES版本是7.6.2，所以我们需要覆盖默认的ES版本：

```plain&#x20;text
<properties>
    <java.version>1.8</java.version>
    <elasticsearch.version>7.12.1</elasticsearch.version>
</properties>
```

结果如下：

![](images/image-36.png)

* 初始化RestHighLevelClient，在测试类HotelIndexTest中编写

```java
package cn.itcast.hotel;

import org.apache.http.HttpHost;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.IOException;

public class HotelIndexTest {
    private RestHighLevelClient client;

    @Test
    void testInit(){
        System.out.println(client);
    }

    @BeforeEach
    void setUp() {
        this.client = new RestHighLevelClient(RestClient.builder(
           HttpHost.create("http://192.168.100.129:9200")
        ));
    }

    @AfterEach
    void tearDown() throws IOException {
        this.client.close();
    }

}
```

运行结果如下：

![](images/image-37.png)



## 4.6.创建索引库

创建索引库的API如下：

通过 Java 客户端向 Elasticsearch 发送创建索引的请求，并将 mapping（字段类型定义）传递给 ES，从而创建一个可搜索的酒店索引库。

![](images/image-38.png)

这段代码的逻辑主要分为三步：**创建请求对象 → 设置 DSL → 发送请求**。

***

**① 创建 Request 对象**

```java
CreateIndexRequest request = new CreateIndexRequest("hotel");
```

因为这里要执行的操作是 **创建索引库（Index）**，所以对应的请求对象是 `CreateIndexRequest`。
&#x20;同时，传入的 `"hotel"` 是索引库的名称，对应 DSL 中的路径：`PUT /hotel`

***

**② 添加请求参数（DSL 内容）**

```java
request.source(MAPPING_TEMPLATE, XContentType.JSON);
```

创建索引时，需要携带一段 JSON 作为 mapping 与 settings 的定义，也就是图右侧的 DSL 内容。

由于 DSL 通常内容较长，直接写在代码里会不美观，所以一般会：

* 预先定义一个 **静态字符串常量** `MAPPING_TEMPLATE`

* 将 JSON（mapping 定义）作为字符串写进去

* 通过 `.source()` 方法传给请求对象

* 指定格式为 `XContentType.JSON`

这一步相当于：

> 把 Mapping（字段类型定义）提交给 ES，让 ES 知道索引库中每个字段应该如何处理。

***

**③ 发送请求，执行创建操作**

```java
client.indices().create(request, RequestOptions.DEFAULT);
```

`client.indices()` 返回 `IndicesClient` 对象，它封装了所有 **索引库相关的操作**，例如：

* create（创建索引）

* exists（判断索引是否存在）

* putMapping（更新 mapping）

* delete（删除索引）

* get（查看索引信息）

这里调用 `.create()` 就是向 Elasticsearch 发送创建索引的指令。

对应 DSL：

```java
PUT /hotel
{"mappings": {"properties": { ... }
  }
}
```

请求成功后，ES 就会创建一个名为 **hotel** 的索引库。

***

完整示例：

在hotel-demo的cn.itcast.hotel.constants包下，创建一个类，定义mapping映射的JSON字符串常量：

```java
package cn.itcast.hotel.constants;

public class HotelConstants {
    public static final String MAPPING_TEMPLATE = "{\n" +
            "  \"mappings\": {\n" +
            "    \"properties\": {\n" +
            "      \"id\": {\n" +
            "        \"type\": \"keyword\"\n" +
            "      },\n" +
            "      \"name\":{\n" +
            "        \"type\": \"text\",\n" +
            "        \"analyzer\": \"ik_max_word\",\n" +
            "        \"copy_to\": \"all\"\n" +
            "      },\n" +
            "      \"address\":{\n" +
            "        \"type\": \"keyword\",\n" +
            "        \"index\": false\n" +
            "      },\n" +
            "      \"price\":{\n" +
            "        \"type\": \"integer\"\n" +
            "      },\n" +
            "      \"score\":{\n" +
            "        \"type\": \"integer\"\n" +
            "      },\n" +
            "      \"brand\":{\n" +
            "        \"type\": \"keyword\",\n" +
            "        \"copy_to\": \"all\"\n" +
            "      },\n" +
            "      \"city\":{\n" +
            "        \"type\": \"keyword\",\n" +
            "        \"copy_to\": \"all\"\n" +
            "      },\n" +
            "      \"starName\":{\n" +
            "        \"type\": \"keyword\"\n" +
            "      },\n" +
            "      \"business\":{\n" +
            "        \"type\": \"keyword\"\n" +
            "      },\n" +
            "      \"location\":{\n" +
            "        \"type\": \"geo_point\"\n" +
            "      },\n" +
            "      \"pic\":{\n" +
            "        \"type\": \"keyword\",\n" +
            "        \"index\": false\n" +
            "      },\n" +
            "      \"all\":{\n" +
            "        \"type\": \"text\",\n" +
            "        \"analyzer\": \"ik_max_word\"\n" +
            "      }\n" +
            "    }\n" +
            "  }\n" +
            "}";
}

```

在hotel-demo中的HotelIndexTest测试类中，编写单元测试，实现创建索引：

1. 创建Request对象。这次是**CreateIndexRequest**对象

2. 准备参数。传入要创建的索引库的名称

3. 发送请求。用create方法

```java
@Test
void createHotelIndex() throws IOException {
    // 1.创建Request对象
    CreateIndexRequest request = new CreateIndexRequest("hotel");
    // 2.准备请求的参数：DSL语句
    request.source(MAPPING_TEMPLATE, XContentType.JSON);
    // 3.发送请求
    client.indices().create(request, RequestOptions.DEFAULT);
}

```

运行测试类，查看dev\_tools，表示创建成功

![](images/image-39.png)



## 4.7删除索引库

删除索引库的DSL语句：

```java
DELETE /hotel
```

与创建索引库相比：

* 请求方式从PUT变为DELTE

* 请求路径不变

* 无请求参数

所以代码的差异，注意体现在Request对象上。依然是三步走：

1. 创建Request对象。这次是**DeleteIndexRequest**对象

2. 准备参数。这里是无参

3. 发送请求。改用delete方法

在hotel-demo中的HotelIndexTest测试类中，编写单元测试，实现删除索引：

```java
@Test
void testDeleteHotelIndex() throws IOException {
    // 1.创建Request对象
    DeleteIndexRequest request = new DeleteIndexRequest("hotel");
    // 2.发送请求
    client.indices().delete(request, RequestOptions.DEFAULT);
}
```

执行后我们去dev\_tools中查询，发现删除成功

![](images/image-40.png)

## 4.7.判断索引库是否存在

判断索引库是否存在，本质就是查询，对应的DSL是：

```java
GET /hotel
```

因此与删除的Java代码流程是类似的。依然是三步走：

* 1）创建Request对象。这次是**GetIndexRequest**对象

* 2）准备参数。这里是无参

* 3）发送请求。改用exists方法

```java
@Test
void testExistsHotelIndex() throws IOException {
    // 1.创建Request对象
    GetIndexRequest request = new GetIndexRequest("hotel");
    // 2.发送请求
    boolean exists = client.indices().exists(request, RequestOptions.DEFAULT);
    // 3.输出
    System.err.println(exists ? "索引库已经存在！" : "索引库不存在！");
}
```

**总结：索引库操作“三步走”**

无论是创建、删除还是查询索引库，都遵循如下固定模式：

* **初始化RestHighLevelClient**

* **创建对应的 Request 对象**

  * CreateIndexRequest

  * DeleteIndexRequest

  * GetIndexRequest

* **准备参数**

  * 创建索引：需要 DSL 映射

  * 删除/查询索引：无参数

* **发送请求**

  * `client.indices().create()`

  * `client.indices().delete()`

  * `client.indices().exists()`

***

# 5.RestClient操作文档

案例：利用JavaRestClient实现文档的CRUD

去数据库查询酒店数据，导入到hotel索引库,实现酒店数据的CRUD。

基本步骤如下:

1. 初始化JavaRestClient

2. 利用JavaRestClient新增酒店数据

3. 利用JavaRestClient根据id查询酒店数据

4. 利用JavaRestClient删 除酒店数据

5. 利用JavaRestClient修 改酒店数据



创建一个测试类HotelDocumentTest，用于文档操作



![](images/image-41.png)













































































































